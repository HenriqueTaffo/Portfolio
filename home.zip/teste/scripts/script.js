$(window).on('load', function() {
    $('.nivoSlider').nivoSlider();
    
    if($(window).width() < 800) {
        $('.dropdown > a').on('click', function(ev) {
            ev.preventDefault();
            $(ev.currentTarget).parent('.dropdown').find('> .submenu').toggleClass('active');
        });
    }

    $('.toggle-menu').on('click', function() {
        $('.menu').toggleClass('active');
    });
});